Plugins are additional software applications that may be used with OpenConf.  Unlike modules, which are specifically developed for OpenConf, plugins are typically generally available applications.

For more information, browse:
https://www.openconf.com/documentation/plugins.php