## +----------------------------------------------------------------------+
## | OpenConf                                                             |
## +----------------------------------------------------------------------+
## | Copyright (c) 2002-2024 Zakon Group LLC.  All Rights Reserved.       |
## +----------------------------------------------------------------------+
## | This source file is subject to the OpenConf License, available on    |
## | the OpenConf web site: www.OpenConf.com                              |
## +----------------------------------------------------------------------+

## NOTE: This file cannot contain a semi-colon (;) except at the end of a
## SQL statement.

# --------------------------------------------------------

DELETE FROM `config` WHERE `module`='mail';
